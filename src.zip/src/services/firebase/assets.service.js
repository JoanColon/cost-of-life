import {
  collection,
  deleteField,
  doc,
  getDoc,
  getDocs,
  query,
  runTransaction,
  serverTimestamp,
  setDoc,
  where,
  writeBatch,
} from 'firebase/firestore'
import { db } from '@/firebase/firebase'
import {
  addItemToCategory,
  allocateValueByOwnership,
  cloneOwnership,
  createEqualOwnership,
  normalizeMoney,
  removeItemFromCategory,
  updateItemInCategory,
} from '@/utils/asset-calculations'

function summaryRef(workspaceId) {
  return doc(db, 'workspaces', workspaceId, 'financialPosition', 'assetsSummary')
}

function assetsRef(workspaceId) {
  return collection(db, 'workspaces', workspaceId, 'assets')
}

export async function getAssetsSummary(workspaceId) {
  const snapshot = await getDoc(summaryRef(workspaceId))
  return snapshot.exists() ? snapshot.data() : null
}

export async function getCategoryAssets(workspaceId, categoryId) {
  const snapshot = await getDocs(query(assetsRef(workspaceId), where('category', '==', categoryId)))

  return snapshot.docs.map((assetDocument) => ({
    id: assetDocument.id,
    ...assetDocument.data(),
  }))
}

export async function saveAssetsSetup(workspaceId, categories, userId) {
  await setDoc(summaryRef(workspaceId), {
    setupCompleted: true,
    categories: stampCategories(categories, userId),
    createdAt: serverTimestamp(),
    createdBy: userId,
    updatedAt: serverTimestamp(),
    updatedBy: userId,
  })
}

export async function updateAssetsCategories(workspaceId, categories, userId) {
  await setDoc(
    summaryRef(workspaceId),
    {
      setupCompleted: true,
      categories: stampCategories(categories, userId),
      updatedAt: serverTimestamp(),
      updatedBy: userId,
    },
    { merge: true },
  )
}

export async function updateSimpleCategoryValue(workspaceId, categoryId, value, userId) {
  const documentRef = summaryRef(workspaceId)

  return runTransaction(db, async (transaction) => {
    const snapshot = await transaction.get(documentRef)
    const category = snapshot.data()?.categories?.[categoryId]
    if (!category || Number(category.itemCount || 0) !== 0) {
      throw new Error('Only simple asset categories can be edited directly')
    }

    const manualValue = normalizeMoney(value)
    if (manualValue === null) throw new Error('A non-negative numeric value is required')

    const updatedCategory = {
      ...category,
      manualValue,
      memberValues: allocateValueByOwnership(manualValue, category.ownership),
      updatedAt: serverTimestamp(),
      updatedBy: userId,
    }

    transaction.update(documentRef, {
      [`categories.${categoryId}`]: updatedCategory,
      updatedAt: serverTimestamp(),
      updatedBy: userId,
    })

    return { ...updatedCategory, updatedAt: null }
  })
}

export async function updateSimpleCategoryOwnership(workspaceId, categoryId, ownership, userId) {
  const documentRef = summaryRef(workspaceId)

  return runTransaction(db, async (transaction) => {
    const snapshot = await transaction.get(documentRef)
    const category = snapshot.data()?.categories?.[categoryId]
    if (!category || Number(category.itemCount || 0) !== 0) {
      throw new Error('Only simple asset category ownership can be edited')
    }

    const updatedCategory = {
      ...category,
      ownership: cloneOwnership(ownership),
      memberValues: allocateValueByOwnership(category.manualValue, ownership),
      updatedAt: serverTimestamp(),
      updatedBy: userId,
    }

    transaction.update(documentRef, {
      [`categories.${categoryId}`]: updatedCategory,
      updatedAt: serverTimestamp(),
      updatedBy: userId,
    })

    return { ...updatedCategory, updatedAt: null }
  })
}

export async function createAsset(workspaceId, asset, userId) {
  const assetRef = doc(assetsRef(workspaceId))
  const documentRef = summaryRef(workspaceId)

  return runTransaction(db, async (transaction) => {
    const summarySnapshot = await transaction.get(documentRef)
    const category = summarySnapshot.data()?.categories?.[asset.category]
    if (!category?.enabled) throw new Error('Asset category is not enabled')

    const currentValue = normalizeMoney(asset.currentValue)
    if (currentValue === null) throw new Error('A non-negative numeric value is required')

    const assetData = {
      ...asset,
      currentValue,
      ownership: cloneOwnership(asset.ownership),
      detail: asset.detail || {},
      valueSource: 'manual',
      createdAt: serverTimestamp(),
      createdBy: userId,
      updatedAt: serverTimestamp(),
      updatedBy: userId,
    }
    const updatedCategory = {
      ...addItemToCategory(category, currentValue, assetData.ownership),
      updatedAt: serverTimestamp(),
      updatedBy: userId,
    }

    transaction.set(assetRef, assetData)
    transaction.update(documentRef, {
      [`categories.${asset.category}`]: updatedCategory,
      updatedAt: serverTimestamp(),
      updatedBy: userId,
    })

    return {
      asset: { ...assetData, id: assetRef.id, createdAt: null, updatedAt: null },
      category: { ...updatedCategory, updatedAt: null },
    }
  })
}

export async function updateAsset(workspaceId, assetId, changes, userId) {
  const assetRef = doc(assetsRef(workspaceId), assetId)
  const documentRef = summaryRef(workspaceId)

  return runTransaction(db, async (transaction) => {
    const [assetSnapshot, summarySnapshot] = await Promise.all([
      transaction.get(assetRef),
      transaction.get(documentRef),
    ])
    if (!assetSnapshot.exists()) throw new Error('Asset not found')

    const previousAsset = assetSnapshot.data()
    const categoryId = previousAsset.category
    const category = summarySnapshot.data()?.categories?.[categoryId]
    if (!category || Number(category.itemCount || 0) === 0) {
      throw new Error('Itemized asset category not found')
    }

    const currentValue = normalizeMoney(changes.currentValue)
    if (currentValue === null) throw new Error('A non-negative numeric value is required')

    const updatedAsset = {
      ...previousAsset,
      ...changes,
      category: categoryId,
      currentValue,
      ownership: cloneOwnership(changes.ownership || previousAsset.ownership),
      detail: changes.detail || previousAsset.detail || {},
      updatedAt: serverTimestamp(),
      updatedBy: userId,
    }
    const updatedCategory = {
      ...updateItemInCategory(
        category,
        previousAsset.currentValue,
        previousAsset.ownership,
        currentValue,
        updatedAsset.ownership,
      ),
      updatedAt: serverTimestamp(),
      updatedBy: userId,
    }

    transaction.update(assetRef, updatedAsset)
    transaction.update(documentRef, {
      [`categories.${categoryId}`]: updatedCategory,
      updatedAt: serverTimestamp(),
      updatedBy: userId,
    })

    return {
      asset: { id: assetId, ...updatedAsset, updatedAt: null },
      category: { ...updatedCategory, updatedAt: null },
    }
  })
}

export async function removeAsset(workspaceId, assetId, userId, memberIds) {
  const assetRef = doc(assetsRef(workspaceId), assetId)
  const documentRef = summaryRef(workspaceId)

  return runTransaction(db, async (transaction) => {
    const [assetSnapshot, summarySnapshot] = await Promise.all([
      transaction.get(assetRef),
      transaction.get(documentRef),
    ])
    if (!assetSnapshot.exists()) throw new Error('Asset not found')

    const asset = assetSnapshot.data()
    const category = summarySnapshot.data()?.categories?.[asset.category]
    if (!category) throw new Error('Asset category not found')

    const updatedCategory = {
      ...removeItemFromCategory(
        category,
        asset.currentValue,
        asset.ownership,
        createEqualOwnership(memberIds),
        memberIds,
      ),
      updatedAt: serverTimestamp(),
      updatedBy: userId,
    }

    transaction.delete(assetRef)
    transaction.update(documentRef, {
      [`categories.${asset.category}`]: updatedCategory,
      updatedAt: serverTimestamp(),
      updatedBy: userId,
    })

    return {
      categoryId: asset.category,
      category: { ...updatedCategory, updatedAt: null },
    }
  })
}

export async function removeAssetCategory(workspaceId, categoryId, userId) {
  const categoryAssetsSnapshot = await getDocs(
    query(assetsRef(workspaceId), where('category', '==', categoryId)),
  )

  if (categoryAssetsSnapshot.size > 498) {
    throw new Error('Asset categories with more than 498 items cannot be deleted in one operation')
  }

  const batch = writeBatch(db)
  categoryAssetsSnapshot.docs.forEach((assetDocument) => batch.delete(assetDocument.ref))
  batch.update(summaryRef(workspaceId), {
    [`categories.${categoryId}`]: deleteField(),
    updatedAt: serverTimestamp(),
    updatedBy: userId,
  })
  await batch.commit()
}

function stampCategories(categories, userId) {
  return Object.fromEntries(
    Object.entries(categories).map(([categoryId, category]) => [
      categoryId,
      {
        ...category,
        updatedAt: serverTimestamp(),
        updatedBy: userId,
      },
    ]),
  )
}
